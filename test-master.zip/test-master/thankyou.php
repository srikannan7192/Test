<?php 
		include_once('assets/includes/_settings.php');
		$site['page']['title'] = 'Thank you!';
		$site['page']['articletitle'] = 'Thank You for Requesting Information From us!';
		//$site['page']['current']['section'] = '';
		$site['page']['current']['page'] = 'thankyou';
		//$site['page']['classes']['body'][] = '';

		include_once('assets/includes/header.php');
?>
<!-- START PAGE CONTENT -->
	<h1 class="mobile_show">Thank You</h1>
	<p>Your request has been sent and an admissions advisor from our school will be contacting you soon. We look forward to speaking with you!</p>

<!-- END PAGE CONTENT -->
<?php 	include_once('assets/includes/footer.php');   ?>