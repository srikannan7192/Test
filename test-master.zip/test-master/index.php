<?php 
		include_once('assets/includes/_settings.php');
		$site['page']['title'] = 'MASTER';
		//$site['page']['articletitle'] = '';
		$site['page']['current']['section'] = 'home';
		//$site['page']['current']['page'] = '';
		//$site['page']['classes']['body'][] = '';

		include_once('assets/includes/header.php');
?>
<!-- START PAGE CONTENT -->
<h1>-----------Master Branch---------</h1>
<h1>Testtt</h1>
<p>
You’ll find EWU in Chicago’s South Loop neighborhood, easily accessible by bus, train and subway. Your professors are experienced professionals, experts in their fields with the ability and willingness to provide the guidance you need to succeed. You’ll also find a financial aid department dedicated to helping you – through part-time employment, grants, scholarships, loans and more – pursue every available means to attend.
<br/><br/>
EWU is one of the most cost-effective education institutions in the regions – coming in 5th for the lowest average graduate student debt in a survey of more than 1000 public and private colleges by the New York Times
</p>




<!-- END PAGE CONTENT -->
<?php 	include_once('assets/includes/footer.php');   ?>
