<section class="">
	<header>Sidebar item header</header>
	<div class="content">
		<p>Sidebar item</p>
	</div>
</section>